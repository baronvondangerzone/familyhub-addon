#!/bin/bash
# Run this from the Home Assistant Terminal add-on
# Copies the Family Hub add-on into the right place so HA can find it

set -e

ADDON_SRC="/share/familyhub-addon"
ADDONS_DIR="/addons"

echo ""
echo "🏠 Installing Family Hub add-on..."
echo ""

# Copy addon files to /addons (local addons directory)
mkdir -p "$ADDONS_DIR/familyhub"
cp -r "$ADDON_SRC/familyhub/"* "$ADDONS_DIR/familyhub/"
cp "$ADDON_SRC/repository.json" "$ADDONS_DIR/repository.json"

echo "✅ Files copied to $ADDONS_DIR/familyhub"
echo ""
echo "Now in Home Assistant:"
echo "  1. Go to Settings → Add-ons → Add-on Store"
echo "  2. Click the 3-dot menu (top right) → Repositories"  
echo "  3. Add: /addons"
echo "  4. Search for 'Family Hub' and install it"
echo "  5. Start it — then open http://homeassistant.local:3000"
echo ""

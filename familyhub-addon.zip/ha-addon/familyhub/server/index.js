const express = require('express');
const cors = require('cors');
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3001;
const DB_PATH = process.env.DB_PATH || path.join(__dirname, '../data/familyhub.db');

// Ensure data directory exists
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);

// Enable WAL mode for better concurrent reads
db.pragma('journal_mode = WAL');

// ── Schema ────────────────────────────────────────────────────────────────────
db.exec(`
  CREATE TABLE IF NOT EXISTS members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    initials TEXT NOT NULL,
    color TEXT NOT NULL,
    pin TEXT DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS shopping_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    added_by TEXT NOT NULL,
    priority TEXT NOT NULL DEFAULT 'P2',
    need_by DATE,
    price REAL DEFAULT 0,
    category TEXT DEFAULT 'General',
    note TEXT DEFAULT '',
    done INTEGER DEFAULT 0,
    done_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    member_id INTEGER NOT NULL,
    member_name TEXT NOT NULL,
    text TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    date TEXT NOT NULL,
    color TEXT DEFAULT '#6c8eff',
    member TEXT,
    all_day INTEGER DEFAULT 1,
    source TEXT DEFAULT 'manual',
    external_id TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  );
`);

// Seed default members if none exist
const memberCount = db.prepare('SELECT COUNT(*) as c FROM members').get();
if (memberCount.c === 0) {
  const insert = db.prepare('INSERT INTO members (name, initials, color) VALUES (?, ?, ?)');
  insert.run('Dad', 'DA', '#6c8eff');
  insert.run('Mom', 'MO', '#f472b6');
  insert.run('Alex', 'AL', '#34d399');
  insert.run('Sam', 'SA', '#fbbf24');
}

app.use(cors());
app.use(express.json());

// ── Members ───────────────────────────────────────────────────────────────────
app.get('/api/members', (req, res) => {
  res.json(db.prepare('SELECT id, name, initials, color FROM members ORDER BY id').all());
});

app.post('/api/members', (req, res) => {
  const { name, initials, color } = req.body;
  const result = db.prepare('INSERT INTO members (name, initials, color) VALUES (?, ?, ?)').run(name, initials, color);
  res.json({ id: result.lastInsertRowid, name, initials, color });
});

app.put('/api/members/:id', (req, res) => {
  const { name, initials, color } = req.body;
  db.prepare('UPDATE members SET name=?, initials=?, color=? WHERE id=?').run(name, initials, color, req.params.id);
  res.json({ ok: true });
});

app.delete('/api/members/:id', (req, res) => {
  db.prepare('DELETE FROM members WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// ── Shopping Items ────────────────────────────────────────────────────────────
app.get('/api/shopping', (req, res) => {
  const items = db.prepare(`
    SELECT * FROM shopping_items ORDER BY done ASC,
    CASE priority WHEN 'P1' THEN 1 WHEN 'P2' THEN 2 WHEN 'P3' THEN 3 ELSE 4 END ASC,
    need_by ASC NULLS LAST, created_at DESC
  `).all();
  res.json(items);
});

app.post('/api/shopping', (req, res) => {
  const { name, added_by, priority, need_by, price, category, note } = req.body;
  const result = db.prepare(
    'INSERT INTO shopping_items (name, added_by, priority, need_by, price, category, note) VALUES (?, ?, ?, ?, ?, ?, ?)'
  ).run(name, added_by, priority || 'P2', need_by || null, price || 0, category || 'General', note || '');
  res.json({ id: result.lastInsertRowid, ...req.body });
});

app.put('/api/shopping/:id', (req, res) => {
  const { name, priority, need_by, price, category, note, done } = req.body;
  db.prepare(`
    UPDATE shopping_items SET name=?, priority=?, need_by=?, price=?, category=?, note=?,
    done=?, done_at=? WHERE id=?
  `).run(name, priority, need_by || null, price, category, note, done ? 1 : 0,
    done ? new Date().toISOString() : null, req.params.id);
  res.json({ ok: true });
});

app.patch('/api/shopping/:id/toggle', (req, res) => {
  const item = db.prepare('SELECT done FROM shopping_items WHERE id=?').get(req.params.id);
  if (!item) return res.status(404).json({ error: 'Not found' });
  const newDone = item.done ? 0 : 1;
  db.prepare('UPDATE shopping_items SET done=?, done_at=? WHERE id=?')
    .run(newDone, newDone ? new Date().toISOString() : null, req.params.id);
  res.json({ done: newDone === 1 });
});

app.delete('/api/shopping/:id', (req, res) => {
  db.prepare('DELETE FROM shopping_items WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

app.delete('/api/shopping/done/all', (req, res) => {
  db.prepare('DELETE FROM shopping_items WHERE done=1').run();
  res.json({ ok: true });
});

// ── Messages ──────────────────────────────────────────────────────────────────
app.get('/api/messages', (req, res) => {
  const limit = parseInt(req.query.limit) || 50;
  res.json(db.prepare('SELECT * FROM messages ORDER BY created_at DESC LIMIT ?').all(limit).reverse());
});

app.post('/api/messages', (req, res) => {
  const { member_id, member_name, text } = req.body;
  const result = db.prepare('INSERT INTO messages (member_id, member_name, text) VALUES (?, ?, ?)')
    .run(member_id, member_name, text);
  res.json({ id: result.lastInsertRowid, member_id, member_name, text, created_at: new Date().toISOString() });
});

// Long-poll endpoint for new messages (simple approach, no WebSockets needed)
app.get('/api/messages/since/:id', (req, res) => {
  const msgs = db.prepare('SELECT * FROM messages WHERE id > ? ORDER BY created_at ASC').all(req.params.id);
  res.json(msgs);
});

// ── Events ────────────────────────────────────────────────────────────────────
app.get('/api/events', (req, res) => {
  const { from, to } = req.query;
  let query = 'SELECT * FROM events';
  const params = [];
  if (from && to) {
    query += ' WHERE date >= ? AND date <= ?';
    params.push(from, to);
  }
  query += ' ORDER BY date ASC';
  res.json(db.prepare(query).all(...params));
});

app.post('/api/events', (req, res) => {
  const { title, date, color, member, all_day, source, external_id } = req.body;
  const result = db.prepare(
    'INSERT INTO events (title, date, color, member, all_day, source, external_id) VALUES (?, ?, ?, ?, ?, ?, ?)'
  ).run(title, date, color || '#6c8eff', member || '', all_day !== false ? 1 : 0, source || 'manual', external_id || null);
  res.json({ id: result.lastInsertRowid, ...req.body });
});

app.put('/api/events/:id', (req, res) => {
  const { title, date, color, member } = req.body;
  db.prepare('UPDATE events SET title=?, date=?, color=?, member=? WHERE id=?')
    .run(title, date, color, member, req.params.id);
  res.json({ ok: true });
});

app.delete('/api/events/:id', (req, res) => {
  db.prepare('DELETE FROM events WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// ── Settings ──────────────────────────────────────────────────────────────────
app.get('/api/settings', (req, res) => {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  const settings = {};
  rows.forEach(r => { settings[r.key] = r.value; });
  res.json(settings);
});

app.post('/api/settings', (req, res) => {
  const stmt = db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)');
  Object.entries(req.body).forEach(([k, v]) => stmt.run(k, v));
  res.json({ ok: true });
});

// ── Health check ──────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ ok: true, time: new Date().toISOString() });
});

// ── Serve React build in production ───────────────────────────────────────────
const buildPath = path.join(__dirname, '../client/build');
if (fs.existsSync(buildPath)) {
  app.use(express.static(buildPath));
  app.get('*', (req, res) => {
    if (!req.path.startsWith('/api')) {
      res.sendFile(path.join(buildPath, 'index.html'));
    }
  });
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`✅ Family Hub server running on port ${PORT}`);
  console.log(`📦 Database: ${DB_PATH}`);
});

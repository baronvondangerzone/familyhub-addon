#!/usr/bin/env node
/**
 * Google Calendar sync script for Family Hub
 * 
 * Setup:
 * 1. Go to https://console.cloud.google.com
 * 2. Create a project → Enable Google Calendar API
 * 3. Create OAuth2 credentials (Desktop app type)
 * 4. Download the JSON and save as /opt/familyhub/google-credentials.json
 * 5. Run this script once manually to authorize: node sync-calendar.js --auth
 * 6. Add to crontab: */30 * * * * node /opt/familyhub/server/sync-calendar.js
 */

const fs = require('fs');
const path = require('path');
const https = require('https');
const Database = require('better-sqlite3');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, '../data/familyhub.db');
const CREDS_PATH = process.env.GOOGLE_CREDS || path.join(__dirname, '../google-credentials.json');
const TOKEN_PATH = process.env.GOOGLE_TOKEN || path.join(__dirname, '../data/google-token.json');

// ── Check if credentials exist ────────────────────────────────────────────────
if (!fs.existsSync(CREDS_PATH)) {
  console.log('');
  console.log('Google Calendar credentials not found.');
  console.log('');
  console.log('To set up Google Calendar sync:');
  console.log('  1. Go to https://console.cloud.google.com');
  console.log('  2. Create a project and enable Google Calendar API');
  console.log('  3. Create OAuth2 Desktop credentials');
  console.log('  4. Download JSON → save as:', CREDS_PATH);
  console.log('  5. Run: node sync-calendar.js --auth');
  console.log('');
  process.exit(0);
}

const credentials = JSON.parse(fs.readFileSync(CREDS_PATH));
const { client_id, client_secret, redirect_uris } = credentials.installed || credentials.web;

// ── Get stored token ──────────────────────────────────────────────────────────
function getToken() {
  if (!fs.existsSync(TOKEN_PATH)) return null;
  return JSON.parse(fs.readFileSync(TOKEN_PATH));
}

function saveToken(token) {
  fs.writeFileSync(TOKEN_PATH, JSON.stringify(token, null, 2));
}

// ── Refresh access token ──────────────────────────────────────────────────────
function refreshAccessToken(refresh_token) {
  return new Promise((resolve, reject) => {
    const params = new URLSearchParams({
      client_id, client_secret,
      refresh_token, grant_type: 'refresh_token'
    });

    const req = https.request({
      hostname: 'oauth2.googleapis.com',
      path: '/token', method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    }, res => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => {
        const json = JSON.parse(data);
        if (json.error) reject(new Error(json.error_description));
        else resolve(json);
      });
    });
    req.on('error', reject);
    req.write(params.toString());
    req.end();
  });
}

// ── Fetch calendar events ─────────────────────────────────────────────────────
function fetchEvents(accessToken, calendarId = 'primary') {
  const now = new Date().toISOString();
  const future = new Date(Date.now() + 60 * 86400000).toISOString(); // 60 days ahead
  const params = new URLSearchParams({
    timeMin: now, timeMax: future,
    singleEvents: 'true', orderBy: 'startTime', maxResults: '100'
  });

  return new Promise((resolve, reject) => {
    const req = https.request({
      hostname: 'www.googleapis.com',
      path: `/calendar/v3/calendars/${encodeURIComponent(calendarId)}/events?${params}`,
      headers: { Authorization: `Bearer ${accessToken}` }
    }, res => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => {
        const json = JSON.parse(data);
        if (json.error) reject(new Error(json.error.message));
        else resolve(json.items || []);
      });
    });
    req.on('error', reject);
    req.end();
  });
}

// ── Main sync ─────────────────────────────────────────────────────────────────
async function sync() {
  const token = getToken();
  if (!token) {
    console.log('Not authorized. Run: node sync-calendar.js --auth');
    return;
  }

  let accessToken = token.access_token;

  // Refresh if expired
  if (Date.now() > (token.expiry_date || 0) - 60000) {
    try {
      const newToken = await refreshAccessToken(token.refresh_token);
      accessToken = newToken.access_token;
      saveToken({ ...token, access_token: accessToken, expiry_date: Date.now() + newToken.expires_in * 1000 });
    } catch (e) {
      console.error('Token refresh failed:', e.message);
      return;
    }
  }

  const db = new Database(DB_PATH);
  const settings = db.prepare("SELECT value FROM settings WHERE key='google_calendar_ids'").get();
  const calendarIds = settings ? settings.value.split(',').map(s => s.trim()) : ['primary'];

  let syncCount = 0;

  for (const calId of calendarIds) {
    try {
      const events = await fetchEvents(accessToken, calId);
      for (const event of events) {
        const date = (event.start.date || event.start.dateTime || '').slice(0, 10);
        const title = event.summary || 'Untitled';
        const exId = event.id;

        // Upsert by external_id
        const existing = db.prepare("SELECT id FROM events WHERE external_id=?").get(exId);
        if (existing) {
          db.prepare("UPDATE events SET title=?, date=? WHERE external_id=?").run(title, date, exId);
        } else {
          db.prepare("INSERT INTO events (title, date, color, member, source, external_id) VALUES (?, ?, '#6c8eff', 'Google Calendar', 'google', ?)")
            .run(title, date, exId);
          syncCount++;
        }
      }
    } catch (e) {
      console.error(`Error syncing calendar ${calId}:`, e.message);
    }
  }

  db.close();
  console.log(`[${new Date().toISOString()}] Synced ${syncCount} new events from Google Calendar`);
}

// ── Auth flow (run once) ──────────────────────────────────────────────────────
async function authorize() {
  const readline = require('readline');
  const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?${new URLSearchParams({
    client_id, redirect_uri: 'urn:ietf:wg:oauth:2.0:oob',
    response_type: 'code', access_type: 'offline',
    scope: 'https://www.googleapis.com/auth/calendar.readonly'
  })}`;

  console.log('\nOpen this URL in a browser and authorize:\n');
  console.log(authUrl);
  console.log('');

  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  rl.question('Paste the authorization code here: ', async (code) => {
    rl.close();
    const params = new URLSearchParams({
      code, client_id, client_secret,
      redirect_uri: 'urn:ietf:wg:oauth:2.0:oob',
      grant_type: 'authorization_code'
    });

    const req = https.request({
      hostname: 'oauth2.googleapis.com',
      path: '/token', method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    }, res => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => {
        const token = JSON.parse(data);
        if (token.error) { console.error('Auth failed:', token.error_description); return; }
        token.expiry_date = Date.now() + token.expires_in * 1000;
        saveToken(token);
        console.log('✅ Authorization successful! Token saved to:', TOKEN_PATH);
        console.log('Now run the sync: node sync-calendar.js');
      });
    });
    req.on('error', console.error);
    req.write(params.toString());
    req.end();
  });
}

if (process.argv.includes('--auth')) {
  authorize();
} else {
  sync().catch(console.error);
}

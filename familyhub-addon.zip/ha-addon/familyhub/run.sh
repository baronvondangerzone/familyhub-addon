#!/usr/bin/with-contenv bashio

# Data lives in /share so it persists across add-on updates
export DB_PATH="/share/familyhub/familyhub.db"
export PORT=3000
export NODE_ENV=production

mkdir -p /share/familyhub

bashio::log.info "Starting Family Hub..."
bashio::log.info "Database: ${DB_PATH}"
bashio::log.info "Open: http://homeassistant.local:3000"

exec node /app/index.js

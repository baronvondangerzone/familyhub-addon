import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Shopping from './pages/Shopping';
import Calendar from './pages/Calendar';
import Messages from './pages/Messages';
import Settings from './pages/Settings';
import { api } from './utils/api';

export default function App() {
  const [page, setPage] = useState('dashboard');
  const [members, setMembers] = useState([]);
  const [urgentCount, setUrgentCount] = useState(0);

  useEffect(() => {
    api.getMembers().then(setMembers).catch(console.error);
  }, []);

  useEffect(() => {
    const checkUrgent = () => {
      api.getShopping().then(items => {
        setUrgentCount(items.filter(i => !i.done && i.priority === 'P1').length);
      }).catch(() => {});
    };
    checkUrgent();
    const t = setInterval(checkUrgent, 30000);
    return () => clearInterval(t);
  }, []);

  const pages = { dashboard: Dashboard, shopping: Shopping, calendar: Calendar, messages: Messages, settings: Settings };
  const PageComponent = pages[page] || Dashboard;

  return (
    <div className="app">
      <Sidebar page={page} setPage={setPage} urgentCount={urgentCount} />
      <div className="main-content">
        <PageComponent members={members} setMembers={setMembers} />
      </div>
    </div>
  );
}

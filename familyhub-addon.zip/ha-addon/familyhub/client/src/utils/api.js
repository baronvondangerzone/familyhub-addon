const BASE = process.env.REACT_APP_API_URL || '';

async function req(method, path, body) {
  const res = await fetch(`${BASE}/api${path}`, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : {},
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) throw new Error(`API ${method} ${path} failed: ${res.status}`);
  return res.json();
}

export const api = {
  // Members
  getMembers: () => req('GET', '/members'),
  addMember: (data) => req('POST', '/members', data),
  updateMember: (id, data) => req('PUT', `/members/${id}`, data),
  deleteMember: (id) => req('DELETE', `/members/${id}`),

  // Shopping
  getShopping: () => req('GET', '/shopping'),
  addShoppingItem: (data) => req('POST', '/shopping', data),
  updateShoppingItem: (id, data) => req('PUT', `/shopping/${id}`, data),
  toggleShoppingItem: (id) => req('PATCH', `/shopping/${id}/toggle`),
  deleteShoppingItem: (id) => req('DELETE', `/shopping/${id}`),
  clearDoneItems: () => req('DELETE', '/shopping/done/all'),

  // Messages
  getMessages: (limit = 50) => req('GET', `/messages?limit=${limit}`),
  postMessage: (data) => req('POST', '/messages', data),
  getMessagesSince: (id) => req('GET', `/messages/since/${id}`),

  // Events
  getEvents: (from, to) => req('GET', `/events${from ? `?from=${from}&to=${to}` : ''}`),
  addEvent: (data) => req('POST', '/events', data),
  updateEvent: (id, data) => req('PUT', `/events/${id}`, data),
  deleteEvent: (id) => req('DELETE', `/events/${id}`),

  // Settings
  getSettings: () => req('GET', '/settings'),
  saveSettings: (data) => req('POST', '/settings', data),
};

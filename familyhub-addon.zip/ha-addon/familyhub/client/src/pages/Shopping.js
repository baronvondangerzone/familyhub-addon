import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../utils/api';

const PRIORITY_LABEL = { P1: 'Urgent', P2: 'Soon', P3: 'Whenever', P4: 'Wishlist' };
const PRIORITY_CLASS = { P1: 'badge-p1', P2: 'badge-p2', P3: 'badge-p3', P4: 'badge-p4' };
const CATEGORIES = ['General', 'Clothing', 'Groceries', 'School', 'Electronics', 'Medical', 'Sports', 'Household', 'Personal Care'];

function Avatar({ member, size = 28 }) {
  if (!member) return null;
  return (
    <div className="avatar" style={{
      width: size, height: size,
      background: member.color + '25',
      color: member.color,
      border: `1.5px solid ${member.color}40`,
      fontSize: size * 0.35,
    }}>
      {member.initials}
    </div>
  );
}

export default function Shopping({ members }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState('all');
  const [editItem, setEditItem] = useState(null);
  const [saving, setSaving] = useState(false);
  const [currentUser, setCurrentUser] = useState('');

  const emptyForm = {
    name: '', added_by: members[0]?.name || '', priority: 'P2',
    need_by: '', price: '', category: 'General', note: ''
  };
  const [form, setForm] = useState(emptyForm);

  const load = useCallback(() => {
    api.getShopping().then(data => { setItems(data); setLoading(false); }).catch(console.error);
  }, []);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { if (members.length) setForm(f => ({ ...f, added_by: f.added_by || members[0].name })); }, [members]);
  useEffect(() => { if (currentUser === '' && members.length) setCurrentUser(members[0].name); }, [members, currentUser]);

  const pending = items.filter(i => !i.done);
  const totalEst = pending.reduce((s, i) => s + (parseFloat(i.price) || 0), 0);
  const p1Items = pending.filter(i => i.priority === 'P1');

  const filtered = items.filter(i => {
    if (filter === 'done') return i.done;
    if (filter === 'pending') return !i.done;
    if (['P1', 'P2', 'P3', 'P4'].includes(filter)) return i.priority === filter && !i.done;
    return true;
  });

  const handleSubmit = async () => {
    if (!form.name.trim()) return;
    setSaving(true);
    try {
      if (editItem) {
        await api.updateShoppingItem(editItem.id, { ...form, done: editItem.done });
      } else {
        await api.addShoppingItem(form);
      }
      load();
      setForm(emptyForm);
      setShowForm(false);
      setEditItem(null);
    } catch (e) { console.error(e); }
    setSaving(false);
  };

  const handleToggle = async (id) => {
    setItems(prev => prev.map(i => i.id === id ? { ...i, done: !i.done } : i));
    try { await api.toggleShoppingItem(id); load(); } catch (e) { load(); }
  };

  const handleDelete = async (id) => {
    setItems(prev => prev.filter(i => i.id !== id));
    try { await api.deleteShoppingItem(id); } catch (e) { load(); }
  };

  const handleEdit = (item) => {
    setForm({
      name: item.name, added_by: item.added_by, priority: item.priority,
      need_by: item.need_by || '', price: item.price || '', category: item.category || 'General', note: item.note || ''
    });
    setEditItem(item);
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const clearDone = async () => {
    if (!window.confirm('Remove all completed items?')) return;
    await api.clearDoneItems();
    load();
  };

  const getMember = (name) => members.find(m => m.name === name);

  const formatDate = (d) => {
    if (!d) return null;
    const date = new Date(d + 'T00:00:00');
    const today = new Date(); today.setHours(0,0,0,0);
    const diff = Math.round((date - today) / 86400000);
    if (diff < 0) return { label: `${Math.abs(diff)}d overdue`, color: 'var(--red)' };
    if (diff === 0) return { label: 'Today', color: 'var(--amber)' };
    if (diff === 1) return { label: 'Tomorrow', color: 'var(--amber)' };
    if (diff <= 7) return { label: `${diff} days`, color: 'var(--text)' };
    return { label: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }), color: 'var(--muted)' };
  };

  if (loading) return <div className="page"><div style={{ display: 'flex', gap: 10, alignItems: 'center', marginTop: 40, color: 'var(--muted)' }}><div className="spinner"></div> Loading...</div></div>;

  return (
    <div className="page">
      <div className="page-header">
        <div className="page-title">Shopping List</div>
        <div className="page-sub">Family purchase requests — sorted by priority</div>
      </div>

      {/* Stats */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-label">Pending</div>
          <div className="stat-value" style={{ color: 'var(--accent)' }}>{pending.length}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Est. Total</div>
          <div className="stat-value" style={{ color: 'var(--green)' }}>${totalEst.toFixed(0)}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Urgent (P1)</div>
          <div className="stat-value" style={{ color: 'var(--red)' }}>{p1Items.length}</div>
        </div>
      </div>

      {/* P1 Callout */}
      {p1Items.length > 0 && (
        <div className="card" style={{ borderColor: 'rgba(248,113,113,0.25)', background: 'rgba(248,113,113,0.04)', marginBottom: 14 }}>
          <div className="card-header" style={{ marginBottom: 10 }}>
            <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--red)' }}>⚡ Urgent — get soon</span>
          </div>
          {p1Items.map(i => {
            const date = formatDate(i.need_by);
            return (
              <div key={i.id} style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 6, fontSize: 13 }}>
                <span className="badge badge-p1">P1</span>
                <strong>{i.name}</strong>
                {date && <span style={{ color: date.color }}>· {date.label}</span>}
                {i.price > 0 && <span style={{ color: 'var(--green)' }}>~${i.price}</span>}
                {i.note && <span style={{ color: 'var(--muted)', fontStyle: 'italic' }}>"{i.note}"</span>}
                <span style={{ color: 'var(--muted)', marginLeft: 'auto', fontSize: 12 }}>— {i.added_by}</span>
              </div>
            );
          })}
        </div>
      )}

      {/* Budget bar */}
      {pending.length > 0 && (
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          background: 'rgba(108,142,255,0.08)', border: '1px solid rgba(108,142,255,0.18)',
          borderRadius: 'var(--radius)', padding: '12px 18px', marginBottom: 16
        }}>
          <div>
            <div style={{ fontSize: 13, color: 'var(--muted)' }}>Estimated budget needed</div>
            <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 1 }}>{pending.length} items pending</div>
          </div>
          <div style={{ fontSize: 22, fontWeight: 700, color: 'var(--accent)' }}>${totalEst.toFixed(0)}</div>
        </div>
      )}

      {/* Toolbar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, flexWrap: 'wrap', gap: 8 }}>
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {['all', 'P1', 'P2', 'P3', 'P4', 'pending', 'done'].map(f => (
            <button key={f} onClick={() => setFilter(f)} style={{
              padding: '4px 12px', borderRadius: 100, fontSize: 12, fontWeight: 500,
              cursor: 'pointer', border: '1px solid',
              borderColor: filter === f ? 'var(--accent)' : 'var(--border2)',
              background: filter === f ? 'var(--accent)' : 'transparent',
              color: filter === f ? '#fff' : 'var(--muted)',
              transition: 'all 0.15s'
            }}>
              {f === 'all' ? 'All' : f === 'pending' ? 'Pending' : f === 'done' ? '✓ Done' : f}
            </button>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          {items.some(i => i.done) && (
            <button className="btn btn-ghost btn-sm" onClick={clearDone}>Clear done</button>
          )}
          <button className="btn btn-primary btn-sm" onClick={() => { setShowForm(!showForm); setEditItem(null); setForm(emptyForm); }}>
            + Add Item
          </button>
        </div>
      </div>

      {/* Add / Edit Form */}
      {showForm && (
        <div className="card" style={{ borderColor: 'var(--border2)', marginBottom: 16 }}>
          <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 14 }}>
            {editItem ? 'Edit item' : 'Add to shopping list'}
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
            <div className="form-group" style={{ gridColumn: '1 / -1' }}>
              <div className="form-label">Item name *</div>
              <input placeholder="e.g. School pants size 10" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} autoFocus />
            </div>
            <div className="form-group">
              <div className="form-label">Added by</div>
              <select value={form.added_by} onChange={e => setForm({ ...form, added_by: e.target.value })}>
                {members.map(m => <option key={m.id}>{m.name}</option>)}
              </select>
            </div>
            <div className="form-group">
              <div className="form-label">Priority</div>
              <select value={form.priority} onChange={e => setForm({ ...form, priority: e.target.value })}>
                <option value="P1">P1 — Urgent (need ASAP)</option>
                <option value="P2">P2 — Soon (this paycheck)</option>
                <option value="P3">P3 — Whenever you can</option>
                <option value="P4">P4 — Wishlist</option>
              </select>
            </div>
            <div className="form-group">
              <div className="form-label">Need by date</div>
              <input type="date" value={form.need_by} onChange={e => setForm({ ...form, need_by: e.target.value })} />
            </div>
            <div className="form-group">
              <div className="form-label">Est. price ($)</div>
              <input type="number" placeholder="0.00" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} />
            </div>
            <div className="form-group">
              <div className="form-label">Category</div>
              <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
                {CATEGORIES.map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div className="form-group" style={{ gridColumn: '1 / -1' }}>
              <div className="form-label">Note / details</div>
              <input placeholder="e.g. Need for Monday's soccer game, size medium" value={form.note} onChange={e => setForm({ ...form, note: e.target.value })} />
            </div>
          </div>

          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-primary" onClick={handleSubmit} disabled={saving || !form.name.trim()}>
              {saving ? 'Saving...' : editItem ? '✓ Save changes' : '+ Add to list'}
            </button>
            <button className="btn btn-ghost" onClick={() => { setShowForm(false); setEditItem(null); setForm(emptyForm); }}>
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Items list */}
      {filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🛒</div>
          <p>{filter === 'all' ? 'No items yet — add something!' : `No ${filter} items`}</p>
        </div>
      ) : (
        filtered.map(item => {
          const member = getMember(item.added_by);
          const date = formatDate(item.need_by);
          return (
            <div key={item.id} style={{
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '11px 14px',
              background: 'var(--bg2)',
              border: `1px solid ${item.done ? 'var(--border)' : 'var(--border2)'}`,
              borderRadius: 'var(--radius-sm)', marginBottom: 7,
              opacity: item.done ? 0.5 : 1, transition: 'all 0.15s'
            }}>
              {/* Checkbox */}
              <div
                onClick={() => handleToggle(item.id)}
                style={{
                  width: 20, height: 20, borderRadius: 5, flexShrink: 0, cursor: 'pointer',
                  border: `2px solid ${item.done ? 'var(--green)' : 'var(--border2)'}`,
                  background: item.done ? 'var(--green)' : 'transparent',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  transition: 'all 0.15s', fontSize: 11, color: '#0f1117', fontWeight: 700
                }}
              >
                {item.done && '✓'}
              </div>

              {/* Info */}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 500, textDecoration: item.done ? 'line-through' : 'none', marginBottom: 3 }}>
                  {item.name}
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', fontSize: 12, color: 'var(--muted)' }}>
                  <span className={`badge ${PRIORITY_CLASS[item.priority]}`}>{item.priority} · {PRIORITY_LABEL[item.priority]}</span>
                  {date && <span style={{ color: date.color }}>📅 {date.label}</span>}
                  {item.price > 0 && <span style={{ color: 'var(--green)' }}>~${item.price}</span>}
                  {item.category !== 'General' && <span>{item.category}</span>}
                  {item.note && <span style={{ fontStyle: 'italic' }}>"{item.note}"</span>}
                </div>
              </div>

              {/* Who added */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0 }}>
                <Avatar member={member} size={24} />
                <span style={{ fontSize: 12, color: 'var(--muted)' }}>{item.added_by}</span>
              </div>

              {/* Actions */}
              <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
                {!item.done && (
                  <button className="btn btn-ghost btn-sm btn-icon" onClick={() => handleEdit(item)} title="Edit">✎</button>
                )}
                <button className="btn btn-danger btn-sm btn-icon" onClick={() => handleDelete(item.id)} title="Delete">✕</button>
              </div>
            </div>
          );
        })
      )}
    </div>
  );
}

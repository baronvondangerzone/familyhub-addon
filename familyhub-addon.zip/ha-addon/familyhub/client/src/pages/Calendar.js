import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../utils/api';

const MEMBER_COLORS = ['#6c8eff','#f472b6','#34d399','#fbbf24','#fb7185','#a78bfa'];

export default function Calendar({ members }) {
  const [events, setEvents] = useState([]);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: '', date: new Date().toISOString().split('T')[0], color: '#6c8eff', member: '' });
  const [saving, setSaving] = useState(false);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const loadEvents = useCallback(() => {
    const from = new Date(year, month - 1, 1).toISOString().split('T')[0];
    const to = new Date(year, month + 2, 0).toISOString().split('T')[0];
    api.getEvents(from, to).then(setEvents).catch(console.error);
  }, [year, month]);

  useEffect(() => { loadEvents(); }, [loadEvents]);

  const monthNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  const dayNames = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  const cells = [];
  for (let i = 0; i < firstDay; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const today = new Date();
  const isToday = (d) => d === today.getDate() && month === today.getMonth() && year === today.getFullYear();

  const getEventsForDay = (d) => {
    const ds = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    return events.filter(e => e.date === ds);
  };

  const handleAdd = async () => {
    if (!form.title.trim() || !form.date) return;
    setSaving(true);
    try {
      await api.addEvent(form);
      loadEvents();
      setForm({ title: '', date: new Date().toISOString().split('T')[0], color: '#6c8eff', member: '' });
      setShowForm(false);
    } catch (e) { console.error(e); }
    setSaving(false);
  };

  const handleDelete = async (id) => {
    await api.deleteEvent(id);
    loadEvents();
  };

  const upcoming = events
    .filter(e => e.date >= today.toISOString().split('T')[0])
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(0, 8);

  return (
    <div className="page">
      <div className="page-header">
        <div className="page-title">Calendar</div>
        <div className="page-sub">Family events and important dates</div>
      </div>

      <div className="notice notice-info">
        <span>📡</span>
        <span>To sync with Google or Apple Calendar, run the sync script after setup — see the README for instructions.</span>
      </div>

      {showForm && (
        <div className="card" style={{ marginBottom: 16 }}>
          <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 12 }}>Add event</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
            <div className="form-group" style={{ gridColumn: '1 / -1' }}>
              <div className="form-label">Title</div>
              <input placeholder="e.g. Soccer game" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} autoFocus />
            </div>
            <div className="form-group">
              <div className="form-label">Date</div>
              <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} />
            </div>
            <div className="form-group">
              <div className="form-label">Family member</div>
              <select value={form.member} onChange={e => {
                const m = members.find(m => m.name === e.target.value);
                setForm({ ...form, member: e.target.value, color: m?.color || form.color });
              }}>
                <option value="">All family</option>
                {members.map(m => <option key={m.id}>{m.name}</option>)}
              </select>
            </div>
          </div>
          <div style={{ marginBottom: 12 }}>
            <div className="form-label" style={{ marginBottom: 6 }}>Color</div>
            <div style={{ display: 'flex', gap: 8 }}>
              {MEMBER_COLORS.map(c => (
                <div key={c} onClick={() => setForm({ ...form, color: c })} style={{
                  width: 24, height: 24, borderRadius: '50%', background: c, cursor: 'pointer',
                  border: form.color === c ? '3px solid #fff' : '3px solid transparent', transition: 'all 0.15s'
                }} />
              ))}
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn btn-primary" onClick={handleAdd} disabled={saving || !form.title.trim()}>
              {saving ? 'Saving...' : '+ Add event'}
            </button>
            <button className="btn btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
          </div>
        </div>
      )}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button className="btn btn-ghost btn-sm" onClick={() => setCurrentDate(new Date(year, month - 1, 1))}>← Prev</button>
          <span style={{ fontSize: 17, fontWeight: 700 }}>{monthNames[month]} {year}</span>
          <button className="btn btn-ghost btn-sm" onClick={() => setCurrentDate(new Date(year, month + 1, 1))}>Next →</button>
        </div>
        <button className="btn btn-primary btn-sm" onClick={() => setShowForm(!showForm)}>+ Add Event</button>
      </div>

      {/* Calendar grid */}
      <div className="card" style={{ padding: 14 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 2, marginBottom: 4 }}>
          {dayNames.map(d => (
            <div key={d} style={{ textAlign: 'center', fontSize: 11, fontWeight: 600, color: 'var(--muted)', padding: '4px 0', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
              {d}
            </div>
          ))}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 2 }}>
          {cells.map((day, i) => {
            const dayEvents = day ? getEventsForDay(day) : [];
            return (
              <div key={i} style={{
                minHeight: 52, padding: '5px 4px', borderRadius: 7, fontSize: 13,
                background: day && isToday(day) ? 'rgba(108,142,255,0.15)' : 'transparent',
                border: `1px solid ${day && isToday(day) ? 'rgba(108,142,255,0.35)' : 'transparent'}`,
                color: day && isToday(day) ? 'var(--accent)' : day ? 'var(--text)' : 'transparent',
                fontWeight: day && isToday(day) ? 700 : 400,
              }}>
                {day && (
                  <>
                    <div style={{ textAlign: 'center', marginBottom: 3 }}>{day}</div>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 2, justifyContent: 'center' }}>
                      {dayEvents.slice(0, 3).map(e => (
                        <div key={e.id} style={{ width: 6, height: 6, borderRadius: '50%', background: e.color }} title={e.title} />
                      ))}
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 10, marginTop: 8 }}>Upcoming</div>
      {upcoming.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">📅</div>
          <p>No upcoming events this month</p>
        </div>
      ) : upcoming.map(e => (
        <div key={e.id} style={{
          display: 'flex', alignItems: 'center', gap: 12,
          padding: '10px 14px', background: 'var(--bg2)',
          border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', marginBottom: 6
        }}>
          <div style={{ width: 10, height: 10, borderRadius: '50%', background: e.color, flexShrink: 0 }}></div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 500 }}>{e.title}</div>
            <div style={{ fontSize: 12, color: 'var(--muted)' }}>
              {new Date(e.date + 'T00:00:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
              {e.member && ` · ${e.member}`}
            </div>
          </div>
          <button className="btn btn-danger btn-sm btn-icon" onClick={() => handleDelete(e.id)}>✕</button>
        </div>
      ))}
    </div>
  );
}

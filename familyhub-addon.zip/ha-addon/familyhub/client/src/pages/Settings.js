import React, { useState, useEffect } from 'react';
import { api } from '../utils/api';

export default function Settings({ members, setMembers }) {
  const [settings, setSettings] = useState({});
  const [saved, setSaved] = useState(false);
  const [newMember, setNewMember] = useState({ name: '', initials: '', color: '#6c8eff' });
  const [showAddMember, setShowAddMember] = useState(false);

  useEffect(() => { api.getSettings().then(setSettings).catch(() => {}); }, []);

  const saveSettings = async () => {
    await api.saveSettings(settings);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const addMember = async () => {
    if (!newMember.name || !newMember.initials) return;
    const m = await api.addMember(newMember);
    setMembers(prev => [...prev, m]);
    setNewMember({ name: '', initials: '', color: '#6c8eff' });
    setShowAddMember(false);
    // reload
    api.getMembers().then(setMembers);
  };

  const deleteMember = async (id) => {
    if (!window.confirm('Remove this family member?')) return;
    await api.deleteMember(id);
    setMembers(prev => prev.filter(m => m.id !== id));
  };

  const COLORS = ['#6c8eff','#f472b6','#34d399','#fbbf24','#fb7185','#a78bfa','#38bdf8','#fb923c'];

  return (
    <div className="page">
      <div className="page-header">
        <div className="page-title">Settings</div>
        <div className="page-sub">Manage family members and app preferences</div>
      </div>

      {/* Family Members */}
      <div className="card">
        <div className="card-header">
          <div className="card-title">👨‍👩‍👧‍👦 Family Members</div>
          <button className="btn btn-primary btn-sm" onClick={() => setShowAddMember(!showAddMember)}>+ Add</button>
        </div>

        {showAddMember && (
          <div style={{ background: 'var(--bg3)', borderRadius: 'var(--radius-sm)', padding: 14, marginBottom: 14 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
              <div className="form-group">
                <div className="form-label">Name</div>
                <input placeholder="e.g. Jordan" value={newMember.name} onChange={e => setNewMember({ ...newMember, name: e.target.value })} />
              </div>
              <div className="form-group">
                <div className="form-label">Initials</div>
                <input placeholder="e.g. JO" maxLength="2" value={newMember.initials} onChange={e => setNewMember({ ...newMember, initials: e.target.value.toUpperCase() })} />
              </div>
            </div>
            <div className="form-label" style={{ marginBottom: 6 }}>Color</div>
            <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
              {COLORS.map(c => (
                <div key={c} onClick={() => setNewMember({ ...newMember, color: c })} style={{
                  width: 24, height: 24, borderRadius: '50%', background: c, cursor: 'pointer',
                  border: newMember.color === c ? '3px solid #fff' : '3px solid transparent'
                }} />
              ))}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn btn-primary btn-sm" onClick={addMember} disabled={!newMember.name || !newMember.initials}>Add member</button>
              <button className="btn btn-ghost btn-sm" onClick={() => setShowAddMember(false)}>Cancel</button>
            </div>
          </div>
        )}

        {members.map(m => (
          <div key={m.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
            <div className="avatar" style={{ width: 36, height: 36, fontSize: 13, fontWeight: 700, background: m.color + '25', color: m.color, border: `2px solid ${m.color}40` }}>{m.initials}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 600 }}>{m.name}</div>
              <div style={{ fontSize: 12, color: 'var(--muted)' }}>Member</div>
            </div>
            <button className="btn btn-danger btn-sm" onClick={() => deleteMember(m.id)}>Remove</button>
          </div>
        ))}
      </div>

      {/* Google Calendar Sync */}
      <div className="card">
        <div className="card-header">
          <div className="card-title">📅 Google Calendar Sync</div>
        </div>
        <div className="notice notice-info" style={{ marginBottom: 12 }}>
          <span>ℹ️</span>
          <span>Google Calendar sync runs as a cron job on your Pi. Set up requires a Google OAuth client ID (free). See the README for full instructions.</span>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 12 }}>
          <div className="form-group">
            <div className="form-label">Google Client ID</div>
            <input
              placeholder="your-id.apps.googleusercontent.com"
              value={settings.google_client_id || ''}
              onChange={e => setSettings({ ...settings, google_client_id: e.target.value })}
            />
          </div>
          <div className="form-group">
            <div className="form-label">Calendar IDs (comma-separated)</div>
            <input
              placeholder="primary,family@group.calendar.google.com"
              value={settings.google_calendar_ids || ''}
              onChange={e => setSettings({ ...settings, google_calendar_ids: e.target.value })}
            />
          </div>
        </div>
        <div style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 10 }}>
          Sync command to add to crontab: <code style={{ background: 'var(--bg3)', padding: '2px 8px', borderRadius: 4, color: 'var(--text)' }}>*/30 * * * * node /opt/familyhub/server/sync-calendar.js</code>
        </div>
      </div>

      {/* App settings */}
      <div className="card">
        <div className="card-header">
          <div className="card-title">⚙️ App Settings</div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
          <div className="form-group">
            <div className="form-label">Family Name</div>
            <input
              placeholder="The Smith Family"
              value={settings.family_name || ''}
              onChange={e => setSettings({ ...settings, family_name: e.target.value })}
            />
          </div>
          <div className="form-group">
            <div className="form-label">Paycheck day of month</div>
            <select value={settings.paycheck_day || '15'} onChange={e => setSettings({ ...settings, paycheck_day: e.target.value })}>
              {Array.from({ length: 31 }, (_, i) => i + 1).map(d => (
                <option key={d} value={d}>{d}{d === 1 ? 'st' : d === 2 ? 'nd' : d === 3 ? 'rd' : 'th'}</option>
              ))}
            </select>
          </div>
        </div>
        <button className="btn btn-primary" onClick={saveSettings}>
          {saved ? '✓ Saved!' : 'Save Settings'}
        </button>
      </div>

      {/* About */}
      <div className="card" style={{ background: 'rgba(108,142,255,0.04)', borderColor: 'rgba(108,142,255,0.12)' }}>
        <div className="card-title" style={{ marginBottom: 10 }}>📦 About</div>
        <div style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 1.8 }}>
          <div>Family Hub v1.0 · Running on your home server</div>
          <div>Database: SQLite (data/familyhub.db)</div>
          <div>Port: {process.env.REACT_APP_API_URL || 'Same server'}</div>
        </div>
      </div>
    </div>
  );
}

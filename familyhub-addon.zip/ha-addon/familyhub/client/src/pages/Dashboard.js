import React, { useState, useEffect } from 'react';
import { api } from '../utils/api';

export default function Dashboard({ members }) {
  const [items, setItems] = useState([]);
  const [events, setEvents] = useState([]);
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    api.getShopping().then(setItems).catch(() => {});
    const today = new Date().toISOString().split('T')[0];
    const end = new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0];
    api.getEvents(today, end).then(setEvents).catch(() => {});
    api.getMessages(5).then(setMessages).catch(() => {});
  }, []);

  const pending = items.filter(i => !i.done);
  const p1 = pending.filter(i => i.priority === 'P1');
  const total = pending.reduce((s, i) => s + (parseFloat(i.price) || 0), 0);

  const getMember = (name) => members.find(m => m.name === name);

  return (
    <div className="page">
      <div className="page-header">
        <div className="page-title">Welcome home 🏠</div>
        <div className="page-sub">{new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}</div>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-label">Shopping Items</div>
          <div className="stat-value" style={{ color: 'var(--accent)' }}>{pending.length}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Urgent (P1)</div>
          <div className="stat-value" style={{ color: p1.length > 0 ? 'var(--red)' : 'var(--green)' }}>{p1.length}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Est. Budget</div>
          <div className="stat-value" style={{ color: 'var(--green)' }}>${total.toFixed(0)}</div>
        </div>
      </div>

      {p1.length > 0 && (
        <div className="card" style={{ borderColor: 'rgba(248,113,113,0.25)', background: 'rgba(248,113,113,0.04)' }}>
          <div className="card-header">
            <span style={{ fontWeight: 600, color: 'var(--red)' }}>⚡ Needs attention</span>
          </div>
          {p1.slice(0, 5).map(i => (
            <div key={i.id} style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 6, fontSize: 13 }}>
              <span className="badge badge-p1">P1</span>
              <span style={{ fontWeight: 500 }}>{i.name}</span>
              {i.need_by && <span style={{ color: 'var(--muted)', fontSize: 12 }}>by {i.need_by}</span>}
              {i.price > 0 && <span style={{ color: 'var(--green)', marginLeft: 'auto' }}>~${i.price}</span>}
            </div>
          ))}
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <div className="card">
          <div className="card-header">
            <div className="card-title">📅 Upcoming Events</div>
          </div>
          {events.length === 0
            ? <div style={{ color: 'var(--muted)', fontSize: 13 }}>No upcoming events</div>
            : events.slice(0, 5).map(e => (
              <div key={e.id} style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
                <div style={{ width: 8, height: 8, borderRadius: '50%', background: e.color, flexShrink: 0 }}></div>
                <div style={{ flex: 1, fontSize: 13, fontWeight: 500 }}>{e.title}</div>
                <span style={{ fontSize: 11, color: 'var(--muted)' }}>{e.date.slice(5)}</span>
              </div>
            ))
          }
        </div>

        <div className="card">
          <div className="card-header">
            <div className="card-title">💬 Recent Messages</div>
          </div>
          {messages.length === 0
            ? <div style={{ color: 'var(--muted)', fontSize: 13 }}>No messages yet</div>
            : messages.slice(-4).map(m => {
              const mem = getMember(m.member_name);
              return (
                <div key={m.id} style={{ display: 'flex', gap: 8, alignItems: 'flex-start', marginBottom: 8 }}>
                  <div className="avatar" style={{
                    width: 24, height: 24, fontSize: 9, fontWeight: 700, flexShrink: 0,
                    background: (mem?.color || '#6c8eff') + '25', color: mem?.color || '#6c8eff',
                    border: `1.5px solid ${(mem?.color || '#6c8eff')}40`
                  }}>{mem?.initials || '?'}</div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <span style={{ fontSize: 12, fontWeight: 600, color: mem?.color || 'var(--text)' }}>{m.member_name}: </span>
                    <span style={{ fontSize: 12, color: 'var(--muted)' }}>{m.text.length > 60 ? m.text.slice(0, 60) + '…' : m.text}</span>
                  </div>
                </div>
              );
            })
          }
        </div>
      </div>

      <div className="card" style={{ background: 'rgba(108,142,255,0.05)', borderColor: 'rgba(108,142,255,0.15)' }}>
        <div className="card-title" style={{ marginBottom: 10 }}>👨‍👩‍👧‍👦 Family Members</div>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          {members.map(m => (
            <div key={m.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 12px', background: m.color + '15', border: `1px solid ${m.color}30`, borderRadius: 100 }}>
              <div className="avatar" style={{ width: 26, height: 26, fontSize: 10, fontWeight: 700, background: m.color + '25', color: m.color, border: `1.5px solid ${m.color}50` }}>{m.initials}</div>
              <span style={{ fontSize: 13, fontWeight: 500 }}>{m.name}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { api } from '../utils/api';

export default function Messages({ members }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [asUser, setAsUser] = useState(null);
  const [sending, setSending] = useState(false);
  const lastIdRef = useRef(0);
  const endRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => { if (members.length && !asUser) setAsUser(members[0]); }, [members, asUser]);

  const loadMessages = useCallback(async () => {
    try {
      const msgs = await api.getMessages(50);
      setMessages(msgs);
      if (msgs.length) lastIdRef.current = Math.max(...msgs.map(m => m.id));
    } catch (e) { console.error(e); }
  }, []);

  useEffect(() => { loadMessages(); }, [loadMessages]);

  // Poll for new messages every 5 seconds
  useEffect(() => {
    const poll = async () => {
      if (lastIdRef.current === 0) return;
      try {
        const newMsgs = await api.getMessagesSince(lastIdRef.current);
        if (newMsgs.length) {
          setMessages(prev => [...prev, ...newMsgs]);
          lastIdRef.current = Math.max(...newMsgs.map(m => m.id));
        }
      } catch (e) {}
    };
    const t = setInterval(poll, 5000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const send = async () => {
    if (!input.trim() || !asUser || sending) return;
    setSending(true);
    const text = input.trim();
    setInput('');
    try {
      const msg = await api.postMessage({ member_id: asUser.id, member_name: asUser.name, text });
      setMessages(prev => [...prev, msg]);
      lastIdRef.current = msg.id;
    } catch (e) { setInput(text); }
    setSending(false);
    inputRef.current?.focus();
  };

  const getMember = (name) => members.find(m => m.name === name);

  const formatTime = (ts) => {
    const d = new Date(ts);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const formatDay = (ts) => {
    const d = new Date(ts);
    const today = new Date(); today.setHours(0,0,0,0);
    const diff = Math.round((d.setHours(0,0,0,0) - today) / 86400000);
    if (diff === 0) return 'Today';
    if (diff === -1) return 'Yesterday';
    return new Date(ts).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  // Group by day
  const grouped = messages.reduce((acc, msg) => {
    const day = msg.created_at.split('T')[0];
    if (!acc[day]) acc[day] = [];
    acc[day].push(msg);
    return acc;
  }, {});

  return (
    <div className="page">
      <div className="page-header">
        <div className="page-title">Family Chat</div>
        <div className="page-sub">Messages sync every 5 seconds across devices on your network</div>
      </div>

      {/* User selector */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16, padding: '10px 14px', background: 'var(--bg2)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)' }}>
        <span style={{ fontSize: 12, color: 'var(--muted)', flexShrink: 0 }}>Chatting as:</span>
        {members.map(m => (
          <div key={m.id} onClick={() => setAsUser(m)} style={{
            display: 'flex', alignItems: 'center', gap: 6,
            padding: '4px 10px', borderRadius: 100, cursor: 'pointer',
            border: `1.5px solid ${asUser?.id === m.id ? m.color : 'transparent'}`,
            background: asUser?.id === m.id ? m.color + '20' : 'transparent',
            transition: 'all 0.15s'
          }}>
            <div className="avatar" style={{ width: 22, height: 22, fontSize: 9, fontWeight: 700, background: m.color + '30', color: m.color, border: `1.5px solid ${m.color}50` }}>{m.initials}</div>
            <span style={{ fontSize: 13, fontWeight: asUser?.id === m.id ? 600 : 400, color: asUser?.id === m.id ? m.color : 'var(--muted)' }}>{m.name}</span>
          </div>
        ))}
      </div>

      {/* Messages */}
      <div style={{
        background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: 'var(--radius)',
        padding: '16px', minHeight: 360, maxHeight: 480, overflowY: 'auto', marginBottom: 12
      }}>
        {messages.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">💬</div>
            <p>No messages yet — say something!</p>
          </div>
        ) : (
          Object.entries(grouped).map(([day, dayMsgs]) => (
            <div key={day}>
              <div style={{ textAlign: 'center', margin: '12px 0 8px', fontSize: 11, color: 'var(--muted)' }}>
                — {formatDay(day + 'T12:00:00')} —
              </div>
              {dayMsgs.map(msg => {
                const isMe = msg.member_name === asUser?.name;
                const member = getMember(msg.member_name);
                return (
                  <div key={msg.id} style={{ display: 'flex', gap: 8, marginBottom: 10, flexDirection: isMe ? 'row-reverse' : 'row', alignItems: 'flex-end' }}>
                    <div className="avatar" style={{
                      width: 28, height: 28, fontSize: 10, fontWeight: 700, flexShrink: 0,
                      background: (member?.color || '#6c8eff') + '25', color: member?.color || '#6c8eff',
                      border: `1.5px solid ${(member?.color || '#6c8eff')}40`
                    }}>{member?.initials || '?'}</div>
                    <div style={{ maxWidth: '72%' }}>
                      {!isMe && <div style={{ fontSize: 11, color: member?.color || 'var(--muted)', marginBottom: 3, fontWeight: 600 }}>{msg.member_name}</div>}
                      <div style={{
                        padding: '9px 13px', borderRadius: 14, fontSize: 13.5, lineHeight: 1.5,
                        background: isMe ? 'rgba(108,142,255,0.2)' : 'var(--bg3)',
                        border: `1px solid ${isMe ? 'rgba(108,142,255,0.3)' : 'var(--border)'}`,
                      }}>
                        {msg.text}
                      </div>
                      <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 3, textAlign: isMe ? 'right' : 'left' }}>
                        {formatTime(msg.created_at)}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ))
        )}
        <div ref={endRef}></div>
      </div>

      {/* Input */}
      <div style={{ display: 'flex', gap: 10 }}>
        <input
          ref={inputRef}
          style={{ flex: 1 }}
          placeholder={asUser ? `Message as ${asUser.name}...` : 'Select who you are above first'}
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()}
          disabled={!asUser}
        />
        <button className="btn btn-primary" onClick={send} disabled={!input.trim() || !asUser || sending}>
          {sending ? '…' : '→ Send'}
        </button>
      </div>
    </div>
  );
}
